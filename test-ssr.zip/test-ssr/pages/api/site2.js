// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

export default (req, res) => {
  res.status(200).json([
    { bannerUrl: 'https://unsplash.com/photos/h2ZTEoRz0wY', bannerImageUrl: 'https://images.unsplash.com/photo-1529998274859-64a3872a3706?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' },
    { bannerUrl: 'https://unsplash.com/photos/-lXN7Ntnhh4', bannerImageUrl: 'https://images.unsplash.com/photo-1613554102935-875c4b28bd5c?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' },
    { bannerUrl: 'https://unsplash.com/photos/Ld8gX4mUp-A', bannerImageUrl: 'https://images.unsplash.com/photo-1613046555475-8971e17c205e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' },
  ])
}
