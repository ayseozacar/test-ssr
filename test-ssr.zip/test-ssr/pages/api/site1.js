// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

export default (req, res) => {
  res.status(200).json([
    { bannerUrl: 'https://unsplash.com/photos/2mMMEVUdXcs', bannerImageUrl: 'https://images.unsplash.com/photo-1613510456351-ae50a32038a9?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' },
    { bannerUrl: 'https://unsplash.com/photos/T51okBef_QQ', bannerImageUrl: 'https://images.unsplash.com/photo-1613574726650-d1ab2eea296a?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' },
    { bannerUrl: 'https://unsplash.com/photos/7S21XSxKxVk', bannerImageUrl: 'https://images.unsplash.com/photo-1550064758-04c17f69818d?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1349&q=80' },
  ])
}
