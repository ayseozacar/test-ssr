import Head from 'next/head'
import BannerSlider from '../components/BannerSlider'
import LangControl from '../components/LangControl'

export default function Site1(props) {
  return (
    <div>
      <BannerSlider data={props.data} />
      <LangControl />
    </div>
  )
}

export async function getServerSideProps(context) {
  const res = await fetch(`http://localhost:3000/api/site1`)
  const data = await res.json()

  if (!data) {
    return {
      notFound: true,
    }
  }

  return {
    props: {
      data
    }, // will be passed to the page component as props
  }
}
