import Head from "next/head";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";

export default function BannerSlider(props) {
  return (
    <div style={{ width: 500, height: 500 }}>
      <Carousel>
        {props.data.map((item) => (
          <a key={item.bannerUrl} href={item.bannerUrl}>
            <img lazy src={item.bannerImageUrl} />
          </a>
        ))}
      </Carousel>
    </div>
  );
}
