import Head from "next/head";

export default function BannerSlider(props) {
  return (
    <div>
      <div>dil seciniz:</div>
      <select>
        <option>Türkçe</option>
        <option>English</option>
      </select>
    </div>
  );
}
